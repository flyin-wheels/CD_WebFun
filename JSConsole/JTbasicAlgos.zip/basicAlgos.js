/* number 1 
var x = [1, 2, 3, 4, 5, 10]
for (var i = 0; i < 5; i++) {
    console.log(i);
}
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
0
1
2
3
4 */

/* number 2 
var x = [1, 2, 3, 4, 5, 10]
for (var i = 0; i < 5; i++) {
    i = i + 1;
    console.log(i);
}
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
1
3
5
*/

/* number 3 
var x = [1, 2, 3, 4, 5, 10]
for (var i = 0; i < 5; i++) {
    i = i + 3;
    console.log(i);
} 
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
3
7
*/

/* number 4 
function y(num1, num2) {  
return num1+num2;
} 
console.log(y(2,3))
console.log(y(3, 5))
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
5
8
*/

/* number 5 
function y(num1, num2) {
    console.log(num1);
    return num1 + num2;
}
console.log(y(2, 3))
console.log(y(3, 5))
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
2
5
3
8
*/

/* number 6 
a = 15;
console.log(a);
function y(a) {
    console.log(a);
    return a;
}
b = y(10);
console.log(b);
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
15
10
10
*/

/* number 7 
a = 15;
console.log(a);
function y(a) {
    console.log(a);
    return a * 2;
}
b = y(10);
console.log(b);
C: \Program Files\nodejs\node.exe JSConsole\basicAlgos.js
15
10
20
*/